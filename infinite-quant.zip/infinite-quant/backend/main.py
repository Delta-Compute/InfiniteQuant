from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI, Request
from pydantic import BaseModel
from tasks import run_backtest  # used for Simulate
from backtest_engine import backtest_hidden_submission  # used for Submit

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # change to your frontend origin in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/submit")
async def handle_strategy_submission(request: Request):
    payload = await request.json()

    strategy = payload.get("strategy")
    user_id = payload.get("user_id")
    submission_id = payload.get("submission_id")
    should_export = payload.get("export", False)

    if should_export:
        print(f"[SUBMIT MODE] Processing submission for {user_id} ({submission_id})")
        return backtest_hidden_submission(strategy, user_id, submission_id)
    else:
        print(f"[SIMULATE MODE] Previewing strategy for {user_id} ({submission_id})")
        return run_backtest(strategy)
