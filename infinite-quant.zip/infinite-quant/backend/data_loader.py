from tiingo import TiingoClient
import pandas as pd
import os
from dotenv import load_dotenv

load_dotenv()

config = {
    'session': True,
    'api_key': os.getenv('TIINGO_API_KEY')
}

client = TiingoClient(config)

# Example: BTCUSD (or change to your preferred symbol like AAPL, EURUSD, etc.)
df = client.get_dataframe(
    tickers="btcusd",
    startDate="2023-01-01",
    endDate="2023-03-01",
    frequency="daily"
)

print(df.head())  # Show structure
