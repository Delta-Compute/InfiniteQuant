import pandas as pd
import numpy as np
from tiingo import TiingoClient
import os
import json
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

client = TiingoClient({
    'session': True,
    'api_key': os.getenv('TIINGO_API_KEY')
})

# === Basic Data + Signal Logic ===
def load_data(symbol="btcusd", start="2023-01-01", end="2023-04-01"):
    df = client.get_dataframe(
        tickers=symbol,
        startDate=start,
        endDate=end,
        frequency="daily"
    )
    return df

def simulate(df):
    trades = []
    in_position = False
    for i in range(1, len(df)):
        if not in_position and df["entry_signal"].iloc[i]:
            entry_price = df["close"].iloc[i]
            entry_time = df.index[i]
            in_position = True
        elif in_position and df["exit_signal"].iloc[i]:
            exit_price = df["close"].iloc[i]
            exit_time = df.index[i]
            pnl = (exit_price - entry_price) / entry_price
            trades.append({
                "entry_time": str(entry_time),
                "exit_time": str(exit_time),
                "entry_price": round(entry_price, 4),
                "exit_price": round(exit_price, 4),
                "pnl": round(pnl, 4),
                "side": "long"
            })
            in_position = False
    return trades

def calc_stats(trades):
    if len(trades) == 0:
        return {"trades": 0, "sharpe": 0, "sortino": 0, "omega": 0, "calmar": 0, "max_floating_dd": 0}

    returns = [t["pnl"] for t in trades]
    mean = np.mean(returns)
    std = np.std(returns)
    downside_std = np.std([r for r in returns if r < 0]) or 1
    sharpe = mean / std * np.sqrt(252)
    sortino = mean / downside_std * np.sqrt(252)
    omega = np.mean([r for r in returns if r > 0]) / abs(np.mean([r for r in returns if r < 0]) or 1)
    calmar = mean / abs(np.min(returns))
    return {
        "trades": len(trades),
        "sharpe": round(sharpe, 2),
        "sortino": round(sortino, 2),
        "omega": round(omega, 2),
        "calmar": round(calmar, 2),
        "max_floating_dd": round(np.min(returns), 4)
    }

# === Normal Strategy Evaluation ===
def backtest_strategy(strategy: dict, user_id=None, submission_id=None):
    df = load_data()

    if strategy["entry"] == "Bollinger Breakout":
        df["ma"] = df["close"].rolling(window=20).mean()
        df["std"] = df["close"].rolling(window=20).std()
        df["upper"] = df["ma"] + 2 * df["std"]
        df["lower"] = df["ma"] - 2 * df["std"]
        df["entry_signal"] = df["close"] > df["upper"]
        df["exit_signal"] = df["close"] < df["ma"]
    else:
        return {"status": "error", "message": "Unsupported entry"}

    split_idx = int(len(df) * 0.7)
    df_is = df.iloc[:split_idx]
    df_oos = df.iloc[split_idx:]

    trades_is = simulate(df_is)
    trades_oos = simulate(df_oos)

    return {
        "user_id": user_id,
        "submission_id": submission_id,
        "strategy": strategy,
        "status": "complete",
        "is": {
            "trades": trades_is,
            "stats": calc_stats(trades_is)
        },
        "oos": {
            "trades": trades_oos,
            "stats": calc_stats(trades_oos)
        }
    }

# === Hidden Submission Backtest ===
def backtest_hidden_submission(strategy, user_id, submission_id):
    # Hardcoded secret validation window (SN-controlled)
    df = load_data(start="2023-06-01", end="2023-07-01")

    if strategy["entry"] == "Bollinger Breakout":
        df["ma"] = df["close"].rolling(window=20).mean()
        df["std"] = df["close"].rolling(window=20).std()
        df["upper"] = df["ma"] + 2 * df["std"]
        df["lower"] = df["ma"] - 2 * df["std"]
        df["entry_signal"] = df["close"] > df["upper"]
        df["exit_signal"] = df["close"] < df["ma"]
    else:
        return {"status": "error", "message": "Unsupported entry"}

    trades = simulate(df)
    stats = calc_stats(trades)

    submission_json = convert_to_submission_format(strategy, user_id, submission_id, trades, stats)
    store_submission_locally(submission_json)
    upload_to_gcp(submission_json)
    send_to_validators(submission_json)

    return submission_json

# === Conversion to BA-like Format ===
def convert_to_submission_format(strategy, user_id, submission_id, trades, stats):
    formatted_trades = []
    account_value = 100000
    position_size = 1  # placeholder
    for i, t in enumerate(trades):
        formatted_trades.append({
            "trade": i,
            "symbol": "btcusd",
            "entryOn": t["entry_time"],
            "exitOn": t["exit_time"],
            "entryValue": t["entry_price"],
            "exitValue": t["exit_price"],
            "accountValue": account_value,
            "positionSize": position_size,
            "positionExposure": "5%",  # placeholder
            "result": round(t["pnl"] * account_value, 2)
        })

    return {
        "symbol": "btcusd",
        "timeframe": strategy.get("timeframe", "1H"),
        "direction": strategy.get("direction", "long"),
        "userID": user_id,
        "submissionID": submission_id,
        "tradingRules": {
            "entry": [strategy.get("entry")],
            "filter": [strategy.get("filter")],
            "exit": [strategy.get("exit")]
        },
        "trades": formatted_trades,
        "stats": stats
    }

# === Output / Transmission ===
def store_submission_locally(results, directory="sn_submissions"):
    os.makedirs(directory, exist_ok=True)
    filename = f"{results['userID']}_{results['submissionID']}.json"
    with open(os.path.join(directory, filename), "w") as f:
        json.dump(results, f, indent=2)

from google.cloud import storage

def upload_to_gcp(results):
    bucket_name = os.getenv("GCP_BUCKET_NAME")
    if not bucket_name:
        raise ValueError("Missing GCP_BUCKET_NAME in .env")

    filename = f"{results['userID']}_{results['submissionID']}.json"
    local_path = os.path.join("/tmp", filename)
    
    # Save locally before upload
    with open(local_path, "w") as f:
        json.dump(results, f, indent=2)

    # Authenticate and upload
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(filename)
    blob.upload_from_filename(local_path)

    from google.cloud import storage

def upload_to_gcp(results):
    bucket_name = os.getenv("GCP_BUCKET_NAME")
    if not bucket_name:
        raise ValueError("Missing GCP_BUCKET_NAME in .env")

    filename = f"{results['userID']}_{results['submissionID']}.json"
    local_path = os.path.join("/tmp", filename)

    # Save JSON locally
    with open(local_path, "w") as f:
        json.dump(results, f, indent=2)

    # Upload to GCP bucket
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(filename)
    blob.upload_from_filename(local_path)

    print(f"[✅] Uploaded {filename} to GCP bucket {bucket_name}")

def send_to_validators(results):
    # TODO: integrate with actual validator RPC/API
    print(f"[mock] Sending submission {results['submissionID']} to validators for scoring...")
