from celery import Celery
from random import uniform, randint

celery = Celery(__name__, broker='redis://redis:6379/0')

@celery.task
def run_backtest(strategy_json):
    print("✅ Received strategy:", strategy_json)

    result = {
        "status": "complete",
        "trades": randint(100, 200),
        "sharpe": round(uniform(0.5, 2.5), 2),
        "sortino": round(uniform(0.6, 3.0), 2),
        "omega": round(uniform(1.1, 1.8), 2),
        "calmar": round(uniform(0.4, 2.0), 2),
        "max_floating_dd": round(uniform(-5.0, -1.0), 2)
    }

    print("📊 Backtest Results:", result)
    return result
