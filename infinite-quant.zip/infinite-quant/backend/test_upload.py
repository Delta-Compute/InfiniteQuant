from backtest_engine import upload_to_gcp

mock_submission = {
    "userID": "test_user",
    "submissionID": "submission_001",
    "symbol": "btcusd",
    "timeframe": "1H",
    "direction": "long",
    "tradingRules": {
        "entry": ["Bollinger Breakout"],
        "filter": ["RSI < 70"],
        "exit": ["1.5x ATR SL"]
    },
    "trades": [],
    "stats": {
        "sharpe": 2.0,
        "sortino": 2.5,
        "omega": 1.3,
        "calmar": 1.2,
        "max_floating_dd": -2.1
    }
}

upload_to_gcp(mock_submission)
