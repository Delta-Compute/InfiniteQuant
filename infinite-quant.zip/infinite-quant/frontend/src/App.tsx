import { useState } from 'react';

const indicators = ["Bollinger Breakout", "ATR Breakout", "Keltner Channel", "Donchian High/Low"];
const filters = ["Volume Spike", "RSI < 70", "Time of Day"];
const exits = ["1.5x ATR SL", "2.5x ATR TP", "Fixed 2% TP"];

export default function App() {
  const [entry, setEntry] = useState('');
  const [filter, setFilter] = useState('');
  const [exit, setExit] = useState('');
  const [timeframe, setTimeframe] = useState('1H');
  const [direction, setDirection] = useState('long');
  const [userId, setUserId] = useState('');
  const [submissionId, setSubmissionId] = useState('');
  const [result, setResult] = useState<any | null>(null);
  const [status, setStatus] = useState<'idle' | 'queued' | 'complete'>('idle');
  const [countdown, setCountdown] = useState(2);

  const runBacktest = async (shouldExport = false) => {
    const strategy = { entry, filter, exit, timeframe, direction };
    const payload = { strategy, user_id: userId, submission_id: submissionId, export: shouldExport };

    setStatus('queued');
    setResult(null);

    let seconds = 2;
    setCountdown(seconds);
    const interval = setInterval(() => {
      seconds -= 1;
      setCountdown(seconds);
      if (seconds <= 0) clearInterval(interval);
    }, 1000);

    const res = await fetch("http://localhost:8000/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const response = await res.json();
    console.log("API Response:", response);

    setTimeout(() => {
      setResult(response);
      setStatus('complete');
    }, 2000);
  };

  return (
    <div className="p-6 max-w-lg mx-auto space-y-4">
      <h1 className="text-2xl font-bold">Strategy Builder</h1>

      <input
        type="text"
        placeholder="User ID"
        value={userId}
        onChange={(e) => setUserId(e.target.value)}
        className="w-full p-2 border rounded"
      />

      <input
        type="text"
        placeholder="Submission ID"
        value={submissionId}
        onChange={(e) => setSubmissionId(e.target.value)}
        className="w-full p-2 border rounded"
      />

      <select onChange={(e) => setEntry(e.target.value)} className="w-full p-2 border">
        <option>Select Entry</option>
        {indicators.map(i => <option key={i}>{i}</option>)}
      </select>

      <select onChange={(e) => setFilter(e.target.value)} className="w-full p-2 border">
        <option>Select Filter</option>
        {filters.map(i => <option key={i}>{i}</option>)}
      </select>

      <select onChange={(e) => setExit(e.target.value)} className="w-full p-2 border">
        <option>Select Exit</option>
        {exits.map(i => <option key={i}>{i}</option>)}
      </select>

      <div className="flex space-x-4">
        <label>Timeframe:
          <select onChange={(e) => setTimeframe(e.target.value)} className="ml-2 p-1 border">
            <option value="1H">1H</option>
            <option value="4H">4H</option>
          </select>
        </label>

        <label>Direction:
          <select onChange={(e) => setDirection(e.target.value)} className="ml-2 p-1 border">
            <option value="long">Long</option>
            <option value="short">Short</option>
            <option value="both">Both</option>
          </select>
        </label>
      </div>

      <div className="flex space-x-4">
        <button
          onClick={() => runBacktest(false)}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          Simulate
        </button>

        <button
          onClick={() => runBacktest(true)}
          className="bg-green-600 text-white px-4 py-2 rounded"
        >
          Submit
        </button>
      </div>

      {status === 'queued' && (
        <div className="mt-4 p-4 bg-yellow-100 rounded border text-sm">
          ⏳ Strategy submitted to queue. Processing... <br />
          Showing results in {countdown} second{countdown !== 1 ? 's' : ''}.
        </div>
      )}

      {result && (
        <div className="mt-4 p-4 bg-gray-100 rounded border text-sm space-y-4">
          <h2 className="font-semibold mb-2">Backtest Results</h2>
          <pre className="bg-white p-2 rounded border overflow-x-auto">
            {JSON.stringify(result, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}
